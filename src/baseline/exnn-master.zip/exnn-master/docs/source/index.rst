.. test documentation master file, created by
   sphinx-quickstart on Fri Dec 10 09:13:46 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

ExNN in Python
==========================================

Enhanced explainable neural network (ExNN) based on sparse, orthogonal and smooth constraints.

Contents:
-----------

.. toctree::
   :maxdepth: 2

   installation.rst
   examples.rst
   modules.rst
