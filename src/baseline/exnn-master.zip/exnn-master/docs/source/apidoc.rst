xNN 
-----------------

xnn\.GAMNet
______________________________
.. automodule:: xnn.GAMNet
  :members:

xnn\.xNN
______________________________

.. automodule:: xnn.xNN
  :members:

xnn\.SOSxNN
______________________________

.. automodule:: xnn.SOSxNN
  :members:
